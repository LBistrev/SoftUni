from unittest import TestCase, main

from project.people.child import Child
from project.rooms.room import Room


class TestRoom(TestCase):
    def setUp(self):
        self.room = Room("Room", 100, 2)

    def test_initialisation(self):
        self.assertEqual("Room", self.room.name)
        self.assertEqual(100, self.room.budget)
        self.assertEqual(2, self.room.members_count)
        self.assertEqual(0, len(self.room.children))
        self.assertEqual(0, self.room.expenses)

    def test_expenses_raises(self):
        with self.assertRaises(ValueError) as ex:
            self.room.expenses = -1
        self.assertEqual("Expenses cannot be negative", str(ex.exception))

    def test_calculate_expenses(self):
        self.assertEqual(0, self.room.expenses)
        child1 = Child(5, 5, 5)
        expected = 450
        self.room.calculate_expenses([child1])
        self.assertEqual(450, expected)


if __name__ == "__main__":
    main()