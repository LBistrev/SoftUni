from unittest import TestCase, main

from project.pet_shop import PetShop


class TestPetShop(TestCase):
    def setUp(self):
        self.pet = PetShop("Test")

    def test_initialisation(self):
        self.assertEqual("Test", self.pet.name)
        self.assertEqual({}, self.pet.food)
        self.assertEqual([], self.pet.pets)

    def test_add_food_with_invalid_quantity_raises(self):
        with self.assertRaises(ValueError) as ex:
            self.pet.add_food("Test", -1)
        self.assertEqual('Quantity cannot be equal to or less than 0', str(ex.exception))

    def test_add_food_with_no_food(self):
        self.assertEqual(0, len(self.pet.food))
        self.pet.add_food("Food", 10)
        self.assertEqual({"Food": 10}, self.pet.food)

    def test_add_food_with_repeated_food(self):
        self.assertEqual(0, len(self.pet.food))
        self.pet.add_food("Food", 10)
        self.assertEqual({"Food": 10}, self.pet.food)
        self.pet.add_food("Food", 10)
        self.assertEqual({"Food": 20}, self.pet.food)

    def test_add_food_repr(self):
        self.assertEqual(f"Successfully added 10.00 grams of Food.", self.pet.add_food("Food", 10))

    def test_add_pet_raises(self):
        self.pet.add_pet("Name")
        with self.assertRaises(Exception) as ex:
            self.pet.add_pet("Name")
        self.assertEqual("Cannot add a pet with the same name", str(ex.exception))

    def test_add_pet_with_invalid_animal(self):
        expected = self.pet.add_pet("Test")
        self.assertEqual(["Test"], self.pet.pets)
        self.assertEqual("Successfully added Test.", expected)

    def test_feed_pet_with_not_animal_in_pets_raises(self):
        self.assertEqual(0, len(self.pet.pets))
        with self.assertRaises(Exception) as ex:
            self.pet.feed_pet("Food", "Test")
        self.assertEqual("Please insert a valid pet name", str(ex.exception))

    def test_feed_pet_with_missed_food(self):
        self.assertEqual({}, self.pet.food)
        self.pet.add_pet("Test")
        self.assertEqual('You do not have Food', self.pet.feed_pet("Food", "Test"))

    def test_feed_pet_with_quantity_less_100(self):
        self.assertEqual({}, self.pet.food)
        self.pet.add_pet("Dog")
        self.pet.add_food("Food", 5)
        self.assertEqual({"Food": 5}, self.pet.food)
        self.pet.feed_pet("Food", "Dog")
        self.assertEqual({"Food": 1005}, self.pet.food)
        self.assertEqual("Dog was successfully fed", self.pet.feed_pet("Food", "Dog"))

    def test_feed_pet_(self):
        self.pet.add_pet("Dog")
        self.pet.add_food("Food", 200)
        self.assertEqual({"Food": 200}, self.pet.food)
        self.pet.feed_pet("Food", "Dog")
        self.assertEqual({"Food": 100}, self.pet.food)

    def test_repr(self):
        self.pet.add_pet("Dog")
        self.pet.add_pet("Cat")
        self.pet.add_food("Food", 10)
        self.assertEqual(f'Shop Test:\n'f'Pets: Dog, Cat', self.pet.__repr__())


if __name__ == "__main__":
    main()
