from unittest import TestCase, main

from project.factory.paint_factory import PaintFactory


class TestPaintFactory(TestCase):
    def setUp(self):
        self.paint = PaintFactory("Test", 100)

    def test_initialisation(self):
        self.assertEqual("Test", self.paint.name)
        self.assertEqual(100, self.paint.capacity)
        self.assertEqual(["white", "yellow", "blue", "green", "red"], self.paint.valid_ingredients)
        self.assertEqual({}, self.paint.ingredients)

    def test_property_products(self):
        self.assertEqual({}, self.paint.products)

    def test_add_ingredient_with_invalid_type_raises(self):
        with self.assertRaises(TypeError) as ex:
            self.paint.add_ingredient("ing", 10)
        self.assertEqual("Ingredient of type ing not allowed in PaintFactory", str(ex.exception))

    def test_add_ingredient_with_bigger_quantity_raises(self):
        with self.assertRaises(ValueError) as ex:
            self.paint.add_ingredient("white", 200)
        self.assertEqual("Not enough space in factory", str(ex.exception))

    def test_add_ingredient_with_valid(self):
        self.assertEqual({}, self.paint.ingredients)
        self.paint.add_ingredient("blue", 10)
        self.assertEqual({"blue": 10}, self.paint.ingredients)

    def test_add_ingredient_with_already_existing_value(self):
        self.assertEqual({}, self.paint.ingredients)
        self.paint.add_ingredient("blue", 10)
        self.assertEqual({"blue": 10}, self.paint.ingredients)
        self.paint.add_ingredient("blue", 10)
        self.assertEqual({"blue": 20}, self.paint.ingredients)

    def test_remove_ingredient_with_invalid_type_raises(self):
        with self.assertRaises(KeyError) as ex:
            self.paint.remove_ingredient("haha", 10)
        self.assertEqual("'No such ingredient in the factory'", str(ex.exception))

    def test_remove_ingredient_with_invalid_quantity_raises(self):
        self.paint.add_ingredient("blue", 10)
        with self.assertRaises(ValueError) as ex:
            self.paint.remove_ingredient("blue", 5000)
        self.assertEqual("Ingredients quantity cannot be less than zero", str(ex.exception))

    def test_remove_ingredient_with_valid_type(self):
        self.paint.add_ingredient("blue", 10)
        self.assertEqual({"blue": 10}, self.paint.ingredients)
        self.paint.remove_ingredient("blue", 10)
        self.assertEqual({"blue": 0}, self.paint.ingredients)


if __name__ == "__main__":
    main()
