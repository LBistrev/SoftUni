from unittest import TestCase, main

from project.mammal import Mammal


class TestMammal(TestCase):
    def setUp(self):
        self.m = Mammal("Kiro", "dog", "woww")

    def test_initialisation(self):
        self.assertEqual("Kiro", self.m.name)
        self.assertEqual("woww", self.m.sound)
        self.assertEqual("dog", self.m.type)
        self.assertEqual("animals", self.m._Mammal__kingdom)

    def test_make_sound_method(self):
        expected = "Kiro makes woww"
        self.assertEqual(expected, self.m.make_sound())

    def test_get_kingdom_method(self):
        self.assertEqual("animals", self.m.get_kingdom())

    def test_info_method(self):
        expected = "Kiro is of type dog"
        self.assertEqual(expected, self.m.info())


if __name__ == "__main__":
    main()