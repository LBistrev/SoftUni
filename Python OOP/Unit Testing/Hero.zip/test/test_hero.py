from unittest import TestCase, main

from project.hero import Hero


class TestHero(TestCase):
    def setUp(self):
        self.hero = Hero("Paladin", 100, 100, 150)
        self.enemy = Hero("Samurai", 10, 10, 10)
        self.hulk = Hero("Hulk", 200000, 200000, 200000)

    def test_initialisation(self):
        self.assertEqual("Paladin", self.hero.username)
        self.assertEqual(100, self.hero.level)
        self.assertEqual(100, self.hero.health)
        self.assertEqual(150, self.hero.damage)

    def test_battle_method_fight_with_yourself_raises(self):
        self.assertEqual("Paladin", self.hero.username)
        with self.assertRaises(Exception) as ex:
            self.hero.battle(self.hero)
        self.assertEqual("You cannot fight yourself", str(ex.exception))

    def test_hero_health_less_than_zero_raises(self):
        self.assertEqual(100, self.hero.health)
        self.hero.health = -2
        self.assertEqual(-2, self.hero.health)
        with self.assertRaises(ValueError) as ex:
            self.hero.battle(self.enemy)
        self.assertEqual("Your health is lower than or equal to 0. You need to rest", str(ex.exception))

    def test_enemy_health_less_than_zero_raises(self):
        self.enemy.health = -1
        with self.assertRaises(ValueError) as ex:
            self.hero.battle(self.enemy)
        self.assertEqual(f"You cannot fight {self.enemy.username}. He needs to rest", str(ex.exception))

    def test_battle_with_valid_players(self):
        self.enemy = Hero("Samurai", 100, 100, 150)
        self.assertEqual("Draw", self.hero.battle(self.enemy))

    def test_battle_where_hero_win(self):
        self.assertEqual("You win", self.hulk.battle(self.enemy))
        self.assertEqual(200001, self.hulk.level)
        self.assertEqual(199905, self.hulk.health)
        self.assertEqual(200005, self.hulk.damage)
        self.assertEqual(10, self.enemy.level)
        self.assertEqual(-39999999990, self.enemy.health)
        self.assertEqual(10, self.enemy.damage)

    def test_battle_where_hero_lose(self):
        self.assertEqual("You lose", self.hero.battle(self.hulk))
        self.assertEqual(200001, self.hulk.level)
        # self.assertEqual(199905, self.hulk.health)
        # self.assertEqual(200005, self.hulk.damage)

    def test_str_representation(self):
        self.assertEqual(f"Hero Paladin: 100 lvl\n" "Health: 100\n" "Damage: 150\n", self.hero.__str__())


if __name__ == "__main__":
    main()
