from project.animals.animal import Mammal
from project.food import Vegetable, Meat, Fruit


class Mouse(Mammal):
    def __init__(self, name, weight, living_region):
        super().__init__(name, weight, living_region)

    def make_sound(self):
        return "Squeak"

    def feed(self, food):
        if type(food) == Vegetable or type(food) == Fruit:
            self.weight += 0.1 * food.quantity
            self.food_eaten += food.quantity
        return f"Mouse does not eat {type(food)}!"


class Dog(Mammal):
    def __init__(self, name, weight, living_region):
        super().__init__(name, weight, living_region)

    def make_sound(self):
        return "Woof!"

    def feed(self, food):
        if type(food) == Meat:
            self.weight += 0.4 * food.quantity
            self.food_eaten += food.quantity
        return f"Dog does not eat {type(food)}!"


class Cat(Mammal):
    def __init__(self, name, weight, living_region):
        super().__init__(name, weight, living_region)

    def make_sound(self):
        return "Meow"

    def feed(self, food):
        if type(food) == Vegetable or type(food) == Meat:
            self.weight += 0.3 * food.quantity
            self.food_eaten += food.quantity
        return f"Cat does not eat {type(food)}!"


class Tiger(Mammal):
    def __init__(self, name, weight, living_region):
        super().__init__(name, weight, living_region)

    def make_sound(self):
        return "ROAR!!!"

    def feed(self, food):
        if type(food) == Meat:
            self.weight += food.quantity
            self.food_eaten += food.quantity
        return f"Tiger does not eat {type(food)}!"


