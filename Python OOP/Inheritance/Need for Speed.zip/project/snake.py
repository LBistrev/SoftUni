from project2.reptile import Reptile


class Snake(Reptile):
    pass

