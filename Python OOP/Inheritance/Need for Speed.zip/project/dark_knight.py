from project2.knight import Knight


class DarkKnight(Knight):
    pass

