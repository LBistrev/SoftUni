from project2.hero import Hero


class Wizard(Hero):
    pass
