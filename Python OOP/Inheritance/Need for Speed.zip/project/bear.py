from project2.mammal import Mammal


class Bear(Mammal):
    pass



