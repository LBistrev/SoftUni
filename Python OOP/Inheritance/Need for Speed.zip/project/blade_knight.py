from project2.dark_knight import DarkKnight


class BladeKnight(DarkKnight):
    pass

