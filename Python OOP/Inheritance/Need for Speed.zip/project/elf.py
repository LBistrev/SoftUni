from project2.hero import Hero


class Elf(Hero):
    pass


