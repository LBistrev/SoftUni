from project2.reptile import Reptile


class Lizard(Reptile):
    pass


