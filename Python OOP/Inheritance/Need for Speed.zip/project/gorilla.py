from project2.mammal import Mammal


class Gorilla(Mammal):
    pass
