from project2.hero import Hero


class Knight(Hero):
    pass
