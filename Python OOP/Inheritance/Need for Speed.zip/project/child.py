from project2.person import Person


class Child(Person):
    pass


