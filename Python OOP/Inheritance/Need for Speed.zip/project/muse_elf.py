from project2.elf import Elf


class MuseElf(Elf):
    pass

