from project2.animal import Animal


class Mammal(Animal):
    pass


