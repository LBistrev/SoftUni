from project2.wizard import Wizard


class DarkWizard(Wizard):
    pass
