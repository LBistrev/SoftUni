from project.car import Car


class SportCar(Car):
    DEFAULT_FUEL_CONSUMPTION = 10


# sport_car = SportCar(150, 150)
# sport_car.drive(50)
# print(sport_car.fuel)
