from project.product import Product


class ProductRepository:
    def __init__(self):
        self.products = []

    def add(self, product: Product):
        self.products.append(product)

    def find(self, product_name: str):
        searched_product = [p for p in self.products if p.name == product_name]
        if searched_product:
            return searched_product[0]

    def remove(self, product_name: str):
        searched_product = [p for p in self.products if p.name == product_name]
        if searched_product:
            self.products.remove(searched_product[0])

    def __repr__(self):
        return "\n".join([f'{p.name}: {p.quantity}' for p in self.products])

